use std::collections::HashMap;
use std::fs;
use std::path::PathBuf;

fn main() {
    let input: String = std::env::args().skip(1).collect::<Vec<_>>().join(" ");

    if input.is_empty() {
        println!("usage: wtf is <command>");
        return;
    }

    let query = input
        .replace("wtf is", "")
        .replace("?", "")
        .trim()
        .to_lowercase();

    // ✅ Use a fixed path in Downloads
    let data_path: PathBuf = dirs::home_dir()  // get home directory
        .unwrap_or_else(|| PathBuf::from("/home/aimar")) // fallback
        .join("Downloads/wtfis-package/commands.json");

    let data = match fs::read_to_string(&data_path) {
        Ok(d) => d,
        Err(_) => {
            eprintln!("Error: could not read database at {:?}", data_path);
            return;
        }
    };

    let commands: HashMap<String, String> = match serde_json::from_str(&data) {
        Ok(c) => c,
        Err(e) => {
            eprintln!("Error: invalid JSON in {:?}:\n{}", data_path, e);
            return;
        }
    };

    match commands.get(&query) {
        Some(desc) => println!("{} → {}", query, desc),
        None => println!("idk what '{}' is 🤷", query),
    }
}
